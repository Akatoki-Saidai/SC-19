[![Build status](https://ci.appveyor.com/api/projects/status/v1pltjps1li83cof?svg=true)](https://ci.appveyor.com/project/SSE4/sys-time-h)

header-only Windows implementation of the `<sys/time.h>` header.

tested on the following compilers:
- Visual Studio
- Clang for Windows (clang-cl)
- GCC (MinGW)

defines the following structures:
- timeval

implements the following functions:
- gettimeofday
